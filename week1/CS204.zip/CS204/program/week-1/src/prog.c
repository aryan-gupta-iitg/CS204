#include <stdio.h>
#include "func.h"


int main(){

	printf("%d\n", add(4,5));


}