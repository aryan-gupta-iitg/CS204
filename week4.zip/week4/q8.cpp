#include <iostream>

using namespace std;

int main(){

    int n;
    cin >> n;

    

    return 0;
}